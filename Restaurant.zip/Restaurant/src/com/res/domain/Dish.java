package com.res.domain;

import java.io.Serializable;

public class Dish implements Serializable{
private String dishname;
private String area;
private double price;
private String dishid;
private double vipprice;
private String path;
private String pictrue;
public double getVipprice() {
	return vipprice;
}
public void setVipprice(double vipprice) {
	this.vipprice = vipprice;
}
public String getPath() {
	return path;
}
public void setPath(String path) {
	this.path = path;
}
public String getPictrue() {
	return pictrue;
}
public void setPictrue(String pictrue) {
	this.pictrue = pictrue;
}
public Dish(String dishname, String area, double price, String dishid, double vipprice, String path, String pictrue) {
	super();
	this.dishname = dishname;
	this.area = area;
	this.price = price;
	this.dishid = dishid;
	this.vipprice = vipprice;
	this.path = path;
	this.pictrue = pictrue;
}
public Dish() {
	super();
}
public Dish(String dishname, String area, Double price, String dishid, Double vipprice) {
	super();
	this.dishname = dishname;
	this.area = area;
	this.price = price;
	this.dishid = dishid;
	this.vipprice = vipprice;
}
public String getDishname() {
	return dishname;
}
public void setDishname(String dishname) {
	this.dishname = dishname;
}
public String getArea() {
	return area;
}
public void setArea(String area) {
	this.area = area;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	
	this.price = price;
}
public String getDishid() {
	return dishid;
}
public void setDishid(String dishid) {
	this.dishid = dishid;
}
public double getVipdish() {
	return vipprice;
}
public void setVipdish(double vipdish) {
	this.vipprice = vipdish;
}
}

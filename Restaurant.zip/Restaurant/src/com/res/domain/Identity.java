package com.res.domain;

import java.io.Serializable;

public class Identity implements Serializable{
private String id;
private String account;
private String password;
private String name;
private int power;
public Identity() {
	super();
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getAccount() {
	return account;
}
public void setAccount(String account) {
	this.account = account;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getPower() {
	return power;
}
public void setPower(int power) {
	this.power = power;
}
public Identity(String account, String password, int power, String name) {
	super();
	this.account = account;
	this.password = password;
	this.name = name;
	this.power = power;
}

}

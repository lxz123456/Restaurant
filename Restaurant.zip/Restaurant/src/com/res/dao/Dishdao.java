package com.res.dao;

import java.util.List;

import com.res.domain.Dish;
import com.res.domain.page;



public interface Dishdao {
List<Dish> selectall();
List<Dish> selepaging(int strat,int current);
int getcount();
void adddish(Dish c);
Dish selebyid(String name);
void update(Dish c);
void delete(String name);
}

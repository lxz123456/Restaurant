package com.res.filer;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.res.domain.Identity;

/**
 * Servlet Filter implementation class Controlfiler
 */
@WebFilter(filterName="/Controlfiler",urlPatterns="/Are/*")
public class Controlfiler implements Filter {

    /**
     * Default constructor. 
     */
    public Controlfiler() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		HttpServletRequest hrt=(HttpServletRequest) request;
		HttpServletResponse respo = (HttpServletResponse) response;
		HttpSession ses = hrt.getSession();
		Identity id=(Identity)ses.getAttribute("user");
		if(id==null){
			System.out.println("过滤器实现");
			request.setAttribute("flag", "对不起您的输入不正确！");
			request.getRequestDispatcher("../Entry/Entry.jsp").forward(request, response);
			//respo.sendRedirect(hrt.getContextPath()+"/Entry.jsp");

			
			
		}
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}

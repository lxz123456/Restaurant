package com.res.bizimple;

import com.res.biz.Idbiz;
import com.res.dao.Iddao;
import com.res.domain.Identity;
import com.res.daoimple.Iddaoimple;
public class Idbizimple implements Idbiz {
private Iddao iddao;
	
	public Idbizimple() {
	super();
	this.iddao = new Iddaoimple();
}

	public Identity login(String acc, String pass) {
		
		return this.iddao.login(acc, pass);
	}

	
	
}

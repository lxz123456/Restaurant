package com.res.biz;

import java.util.List;

import com.res.domain.*;


public interface Dishbiz {
	Dish selebyname(String name);
	List<Dish> selectall();
	page selepag(String page);
	void adddish(Dish c);
	void update(Dish c);
	void delete(String name);
}

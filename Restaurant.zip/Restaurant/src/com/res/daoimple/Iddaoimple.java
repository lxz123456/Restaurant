package com.res.daoimple;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.dbutil.dbutil;

import com.res.dao.Iddao;
import com.res.domain.Identity;

public class Iddaoimple implements Iddao {

	@Override
	public Identity login(String acc, String pass) {
		dbutil db = new dbutil();
		String sql = "select * from userres where account=? and password=?";
		ResultSet rs = db.query(sql, acc, pass);
		try {
			if (rs.next()) {
				System.out.println("已经执行！");
				return new Identity(rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.close();

		return null;
	}

}

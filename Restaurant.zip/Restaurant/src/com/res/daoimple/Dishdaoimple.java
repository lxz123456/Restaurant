package com.res.daoimple;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dbutil.dbutil;
import com.res.dao.Dishdao;
import com.res.domain.Dish;
import com.res.domain.Identity;
import com.res.domain.page;



public class Dishdaoimple implements Dishdao {

	@Override
	public List<Dish> selectall() {
		List <Dish> list=new ArrayList<>();
		dbutil db = new dbutil();
		String sql = "select * from dish";
		ResultSet rs = db.query(sql);
		try {
			while(rs.next()){
				list.add(new Dish(rs.getString(1), rs.getString(2), rs.getDouble(3), rs.getString(4),rs.getDouble(5),rs.getString(6),rs.getString(7)));	
			return list;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.close();

		
		return null;
	}

	@Override
	public List<Dish> selepaging(int strat, int current) {
		List <Dish> list=new ArrayList<>();
		dbutil db=new dbutil();	
		String sql="select * from dish limit ?,?";
		ResultSet rs= db.query(sql, strat,current);
		try {
			while(rs.next()){
				list.add(new Dish(rs.getString(1), rs.getString(2), rs.getDouble(3), rs.getString(4),rs.getDouble(5),rs.getString(6),rs.getString(7)));	
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{db.close();}
		return null;
	}

	@Override
	public int getcount() {
		// TODO Auto-generated method stub
				List <Dish> list=new ArrayList<>();
				dbutil db=new dbutil();	
				String sql="select count(*) from dish ";
				ResultSet rs= db.query(sql);
				try {
					if(rs.next()){
						
						return rs.getInt(1);
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally {
					db.close();
				}
				return 0;
	}

	@Override
	public void adddish(Dish c) {
		// TODO Auto-generated method stub
		dbutil db=new dbutil();
		String sql="insert into dish values(?,?,?,?,?,?,?)";
		db.update(sql,c.getDishname(),c.getArea(),c.getPrice(),c.getDishid(),c.getVipdish(),c.getPath(),c.getPictrue());
		db.close();
	}

	@Override
	public Dish selebyid(String name) {
		
		dbutil db=new dbutil();	
		String sql="select * from dish where dishname=?";
		ResultSet rs=db.query(sql,name);
		
		try {
			if(rs.next()){
				
				return new Dish(rs.getString(1), rs.getString(2), rs.getDouble(3), rs.getString(4),rs.getDouble(5),rs.getString(6),rs.getString(7));
			}else{
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			db.close();
		}
		
		return null;
	}

	@Override
	public void update(Dish c) {
		dbutil db=new dbutil();
		System.out.println("kais");
		String sql="UPDATE dish SET dishname=?,area=?,price=?,dishid=?,vipprice=?,path=?,pictrue=? WHERE dishname = ?";
		db.update(sql,c.getDishname(),c.getArea(),c.getPrice(),c.getDishid(),c.getVipdish(),c.getPath(),c.getPictrue(),c.getDishname());
		
		db.close();
		
	}

	@Override
	public void delete(String name) {
		dbutil db=new dbutil();
		
		String sql="DELETE FROM dish WHERE dishname = ?";
		db.update(sql,name);
		
		db.close();
		
	}

	
	

}
